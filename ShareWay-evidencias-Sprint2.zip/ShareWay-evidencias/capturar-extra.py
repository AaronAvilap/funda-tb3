import json,uuid,hashlib,time,urllib.request,urllib.error
from pathlib import Path
from datetime import datetime,timezone
from playwright.sync_api import sync_playwright
ROOT=Path('/workspace/evidencia-shareway');(ROOT/'capturas').mkdir(exist_ok=True)
results=json.loads((ROOT/'resultados.json').read_text()) if (ROOT/'resultados.json').exists() else []
_uuid_counter=0
def stable_uuid():
 global _uuid_counter
 _uuid_counter+=1
 return uuid.uuid5(uuid.NAMESPACE_URL,'shareway-evidence-20261101-v2-'+str(_uuid_counter))
uuid.uuid4=stable_uuid
BASE={'planning':'http://localhost:8081','driver':'http://localhost:18082','payments':'http://localhost:18085','booking':'http://localhost:18080','execution':'http://localhost:18083'}
def api(s,m,path,body=None,token=None):
 h={'Content-Type':'application/json'}
 if token:h['Authorization']='Bearer '+token
 req=urllib.request.Request(BASE[s]+path,data=json.dumps(body).encode() if body is not None else None,headers=h,method=m)
 with urllib.request.urlopen(req) as r:return json.load(r)
def jwt(uid,role):
 import base64,hmac
 def enc(x):return base64.urlsafe_b64encode(json.dumps(x,separators=(',',':')).encode()).decode().rstrip('=')
 a=enc({'alg':'HS256','typ':'JWT'})+'.'+enc({'sub':'evidence@example.test','userId':uid,'role':role,'exp':int(time.time())+3600})
 return a+'.'+base64.urlsafe_b64encode(hmac.new(b'evidence-only-jwt-secret-minimum-thirty-two-characters',a.encode(),hashlib.sha256).digest()).decode().rstrip('=')
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1500,'height':1100},device_scale_factor=1);page.set_default_timeout(10000)
 service=None
 def run(s,method,path,label,body=None,params=None,auth=None,expected=200,desc=''):
  global service
  existing=next((r for r in results if r['capture']=='capturas/'+label+'.png'),None)
  if existing:
   return existing['response']
  if service!=s:
   page.goto(BASE[s]+('/swagger/index.html' if s=='execution' else '/swagger-ui/index.html'))
   page.wait_for_selector('.opblock',timeout=30000);service=s
  if auth:
   # Use Swagger UI's own supported authorization API; no response or contract substitution.
   scheme='internalApiKey' if auth=='internal' else 'bearerAuth'
   value='evidence-local-api-key' if auth=='internal' else auth
   page.evaluate('([name,value])=>window.ui.preauthorizeApiKey(name,value)',[scheme,value])
  op=page.locator('.opblock').filter(has=page.locator('.opblock-summary-path').filter(has_text=path))
  # exact method and path, because paths may contain each other
  op=page.locator('.opblock').filter(has=page.locator('.opblock-summary-path',has_text=path)).filter(has=page.locator('.opblock-summary-method',has_text=method.upper()))
  matches=[]
  for i in range(op.count()):
   x=op.nth(i)
   if x.locator('.opblock-summary-path').inner_text().strip()==path:matches.append(x)
  assert len(matches)==1,(s,method,path,len(matches))
  op=matches[0]
  if 'is-open' not in op.get_attribute('class'):op.locator('.opblock-summary').click()
  op.locator('.try-out__btn').first.wait_for()
  if op.locator('.try-out__btn').first.inner_text().strip()=='Try it out':op.locator('.try-out__btn').first.click()
  if body is not None:op.locator('textarea.body-param__text').fill(json.dumps(body,indent=2))
  for k,v in (params or {}).items():
   tr=op.locator('tr').filter(has=page.locator(f'[data-param-name="{k}"]'))
   tr=op.locator(f'tr[data-param-name="{k}"]')
   if not tr.count():tr=op.locator('tr').filter(has=page.locator('.parameter__name',has_text=k))
   tr.locator('input').first.fill(str(v))
  with page.expect_response(lambda r:r.request.method==method.upper() and r.url.startswith(BASE[s]) and '/swagger' not in r.url,timeout=30000) as resp:
   op.get_by_role('button',name='Execute',exact=True).click()
  response=resp.value
  try:data=response.json()
  except:data=response.text()
  op.locator('.live-responses-table').wait_for(timeout=15000)
  # Capture the operation through its live response, excluding static documented-response rows below.
  page.wait_for_timeout(150)
  box=op.bounding_box();live=op.locator('.live-responses-table').bounding_box()
  file='capturas/'+label+'.png'
  op.screenshot(path=str(ROOT/file),animations='disabled')
  op.locator('.live-responses-table').screenshot(path=str(ROOT/('capturas/'+label+'-respuesta.png')),animations='disabled')
  item={'service':s,'method':method,'path':path,'parameters':params,'request':body,'status':response.status,'expected':expected,'response':data,'capture':file,'description':desc,'timestamp_utc':datetime.now(timezone.utc).isoformat()}
  results.append(item);(ROOT/'resultados.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
  print(label,response.status,flush=True)
  # Keep failures visible and continue independent cases.
  item['passed']=response.status==expected
  (ROOT/'resultados.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
  op.locator('.opblock-summary').click()
  return data

 run('driver','post','/api/v1/auth/register','27-registro-pasajero',{'email':'passenger.evidence@example.test','password':'Evidence123','fullName':'Pasajero de Prueba','phone':'999555666'},expected=201)
 token=api('driver','POST','/api/v1/auth/login',{'email':'driver.evidence2@example.test','password':'Evidence123'})['accessToken']
 import io
 from PIL import Image
 im=Image.new('RGB',(400,200),'white');buf=io.BytesIO();im.save(buf,format='PNG')
 boundary='SharewayEvidenceBoundary'
 raw=(f'--{boundary}\r\nContent-Disposition: form-data; name="type"\r\n\r\nDRIVERS_LICENSE\r\n--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="documento-prueba.png"\r\nContent-Type: image/png\r\n\r\n').encode()+buf.getvalue()+f'\r\n--{boundary}--\r\n'.encode()
 req=urllib.request.Request(BASE['driver']+'/api/v1/drivers/me/documents',data=raw,headers={'Authorization':'Bearer '+token,'Content-Type':'multipart/form-data; boundary='+boundary},method='POST')
 with urllib.request.urlopen(req) as r:
  assert r.status==201
  doc=json.load(r)

 admin=api('driver','POST','/api/v1/auth/login',{'email':'admin@example.test','password':'EvidenceAdmin123'})['accessToken']
 run('driver','patch','/api/v1/driver-documents/{id}/review','28-revisar-documento',{'decision':'APPROVED'},params={'id':doc['id']},auth=admin)
 browser.close()
