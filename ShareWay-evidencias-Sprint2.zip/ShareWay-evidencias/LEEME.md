# Evidencias ShareWay — revisión del Sprint 2

Evidencia obtenida el 1 de noviembre de 2026 en servicios ejecutados localmente desde las ramas main revisadas. Las capturas muestran Swagger UI y respuestas reales del servidor. No se modificó ningún repositorio, ni se escribieron datos en Render. Se utilizaron bases PostgreSQL locales aisladas, H2 para las suites que lo configuran, datos ficticios y credenciales exclusivamente locales. Esta evidencia no demuestra el despliegue en Render ni una integración automática de extremo a extremo.

## Resultado

28 casos funcionales ejecutados: 27 con el estado HTTP esperado y 1 fallido. Tres comparaciones de idempotencia verificadas: propuestas, reserva y liquidación.

## Suites existentes

| Servicio | Resultado del runner | Registro |
|---|---|---|
| Trip Planning & Matching | 4 ejecuciones; sin fallos, errores ni omitidos | [Log](logs/trip-planning-tests.log) |
| Driver Management | 112 ejecuciones; sin fallos, errores ni omitidos | [Log](logs/driver-tests.log) |
| Booking & Pricing | 109 ejecuciones; sin fallos, errores ni omitidos | [Log](logs/booking-tests.log) |
| Payments & Settlement | 93 ejecuciones; sin fallos, errores ni omitidos | [Log](logs/payments-tests-verified.log) |
| API Gateway | 75 ejecuciones; sin fallos, errores ni omitidos | [Log](logs/gateway-tests.log) |

## Alcance y limitaciones

- Trip Execution no contiene una suite automatizada: se verificó compilación con .NET 10 (0 errores y 0 advertencias) y se ejecutaron los casos funcionales de este anexo.
- Caso 15: iniciar sin pasajeros abordados devolvió HTTP 500; se esperaba 409 según el manejo de errores declarado por el proyecto. Se conserva como fallo, sin modificar código.
- Iniciar y finalizar el viaje devolvieron HTTP 200; las anotaciones OpenAPI de esas operaciones anuncian 204.
- Los JWT de Payments fueron firmados para esta instancia local con identidades de prueba. La autorización de Driver Management sí se obtuvo mediante su login. No se prueba interoperabilidad de identidades entre servicios.
- El evento trip-completed de Payments se envió manualmente por Swagger con datos de prueba; no se prueba transporte automático desde Trip Execution. La pasarela de pagos del proyecto es simulada.
- La cancelación de Booking observada no produjo penalidad (penaltyAmount y currency nulos). No se capturó aquí el cobro por cancelación tardía. Las políticas por defecto siguen siendo distintas: Booking 20 % y Payments 50 %.
- La captura 29 muestra la documentación agrupada del gateway con Driver Management seleccionado. No demuestra que las rutas de todos los servicios funcionen a través del gateway. Booking conserva la diferencia de prefijo detectada.
- Para iniciar Trip Planning se usó currentSchema=shareway en la URL JDBC, de modo que Hibernate consulte el esquema migrado por Flyway; fue una configuración de ejecución, no un cambio del repositorio.
- Payments: Maven informa 93 ejecuciones y su XML agregado de Cucumber representa 48 casos frente a 54 informados en consola; el total XML es 87. Se incluyen ambos artefactos y no se presenta el total de consola como número de casos únicos.

## Capturas y pies sugeridos

### 1. 01 disponibilidad operativa

Figura 1. Trip Planning & Matching: POST /api/v1/driver-availabilities. Respuesta observada HTTP 201; esperada HTTP 201. Registro de disponibilidad operativa por fecha.

[Captura completa](capturas/01-disponibilidad-operativa.png) · [Respuesta](capturas/01-disponibilidad-operativa-respuesta.png)

### 2. 02 solicitud viaje

Figura 2. Trip Planning & Matching: POST /api/v1/trip-requests. Respuesta observada HTTP 201; esperada HTTP 201. Solicitud compatible con la disponibilidad creada.

[Captura completa](capturas/02-solicitud-viaje.png) · [Respuesta](capturas/02-solicitud-viaje-respuesta.png)

### 3. 03 generar propuestas

Figura 3. Trip Planning & Matching: POST /api/v1/trip-requests/{tripRequestId}/match-proposals. Respuesta observada HTTP 200; esperada HTTP 200. Matching por zona, fecha, horario y cupos.

[Captura completa](capturas/03-generar-propuestas.png) · [Respuesta](capturas/03-generar-propuestas-respuesta.png)

### 4. 04 repeticion idempotente

Figura 4. Trip Planning & Matching: POST /api/v1/trip-requests/{tripRequestId}/match-proposals. Respuesta observada HTTP 200; esperada HTTP 200. Repetición de la generación; se comprueba que devuelve los mismos IDs.

[Captura completa](capturas/04-repeticion-idempotente.png) · [Respuesta](capturas/04-repeticion-idempotente-respuesta.png)

### 5. 05 consultar propuestas

Figura 5. Trip Planning & Matching: GET /api/v1/trip-requests/{tripRequestId}/match-proposals. Respuesta observada HTTP 200; esperada HTTP 200.

[Captura completa](capturas/05-consultar-propuestas.png) · [Respuesta](capturas/05-consultar-propuestas-respuesta.png)

### 6. 06 validacion solicitud invalida

Figura 6. Trip Planning & Matching: POST /api/v1/trip-requests. Respuesta observada HTTP 400; esperada HTTP 400. Validación de campos obligatorios.

[Captura completa](capturas/06-validacion-solicitud-invalida.png) · [Respuesta](capturas/06-validacion-solicitud-invalida-respuesta.png)

### 7. 07 guardar agenda semanal

Figura 7. Driver Management: PUT /api/v1/drivers/me/availability. Respuesta observada HTTP 200; esperada HTTP 200.

[Captura completa](capturas/07-guardar-agenda-semanal.png) · [Respuesta](capturas/07-guardar-agenda-semanal-respuesta.png)

### 8. 08 consultar agenda semanal

Figura 8. Driver Management: GET /api/v1/drivers/me/availability. Respuesta observada HTTP 200; esperada HTTP 200.

[Captura completa](capturas/08-consultar-agenda-semanal.png) · [Respuesta](capturas/08-consultar-agenda-semanal-respuesta.png)

### 9. 09 rechazar solapamiento

Figura 9. Driver Management: PUT /api/v1/drivers/me/availability. Respuesta observada HTTP 400; esperada HTTP 400.

[Captura completa](capturas/09-rechazar-solapamiento.png) · [Respuesta](capturas/09-rechazar-solapamiento-respuesta.png)

### 10. 10 estimar tarifa

Figura 10. Booking & Pricing: GET /fares/estimate. Respuesta observada HTTP 200; esperada HTTP 200.

[Captura completa](capturas/10-estimar-tarifa.png) · [Respuesta](capturas/10-estimar-tarifa-respuesta.png)

### 11. 11 crear reserva

Figura 11. Booking & Pricing: POST /bookings. Respuesta observada HTTP 202; esperada HTTP 202.

[Captura completa](capturas/11-crear-reserva.png) · [Respuesta](capturas/11-crear-reserva-respuesta.png)

### 12. 12 reserva idempotente

Figura 12. Booking & Pricing: POST /bookings. Respuesta observada HTTP 202; esperada HTTP 202.

[Captura completa](capturas/12-reserva-idempotente.png) · [Respuesta](capturas/12-reserva-idempotente-respuesta.png)

### 13. 13 cancelar reserva

Figura 13. Booking & Pricing: POST /bookings/{bookingId}/cancel. Respuesta observada HTTP 200; esperada HTTP 200.

[Captura completa](capturas/13-cancelar-reserva.png) · [Respuesta](capturas/13-cancelar-reserva-respuesta.png)

### 14. 14 crear viaje

Figura 14. Trip Execution: POST /api/viajes. Respuesta observada HTTP 201; esperada HTTP 201.

[Captura completa](capturas/14-crear-viaje.png) · [Respuesta](capturas/14-crear-viaje-respuesta.png)

### 15. 15 rechazar inicio sin abordaje

Figura 15. Trip Execution: POST /api/viajes/{id}/iniciar. Respuesta observada HTTP 500; esperada HTTP 409.

[Captura completa](capturas/15-rechazar-inicio-sin-abordaje.png) · [Respuesta](capturas/15-rechazar-inicio-sin-abordaje-respuesta.png)

### 16. 16 validar abordaje

Figura 16. Trip Execution: POST /api/viajes/{id}/abordajes. Respuesta observada HTTP 200; esperada HTTP 200.

[Captura completa](capturas/16-validar-abordaje.png) · [Respuesta](capturas/16-validar-abordaje-respuesta.png)

### 17. 17 iniciar viaje

Figura 17. Trip Execution: POST /api/viajes/{id}/iniciar. Respuesta observada HTTP 200; esperada HTTP 200. Respuesta observada 200; las anotaciones también anuncian 204.

[Captura completa](capturas/17-iniciar-viaje.png) · [Respuesta](capturas/17-iniciar-viaje-respuesta.png)

### 18. 18 finalizar viaje

Figura 18. Trip Execution: POST /api/viajes/{id}/finalizar. Respuesta observada HTTP 200; esperada HTTP 200.

[Captura completa](capturas/18-finalizar-viaje.png) · [Respuesta](capturas/18-finalizar-viaje-respuesta.png)

### 19. 19 consultar viaje finalizado

Figura 19. Trip Execution: GET /api/viajes/{id}. Respuesta observada HTTP 200; esperada HTTP 200.

[Captura completa](capturas/19-consultar-viaje-finalizado.png) · [Respuesta](capturas/19-consultar-viaje-finalizado-respuesta.png)

### 20. 20 registrar metodo pago

Figura 20. Payments & Settlement: POST /api/v1/payment-methods. Respuesta observada HTTP 201; esperada HTTP 201.

[Captura completa](capturas/20-registrar-metodo-pago.png) · [Respuesta](capturas/20-registrar-metodo-pago-respuesta.png)

### 21. 21 autorizar pago

Figura 21. Payments & Settlement: POST /api/v1/internal/payments/authorizations. Respuesta observada HTTP 201; esperada HTTP 201.

[Captura completa](capturas/21-autorizar-pago.png) · [Respuesta](capturas/21-autorizar-pago-respuesta.png)

### 22. 22 capturar y liquidar

Figura 22. Payments & Settlement: POST /api/v1/internal/events/trip-completed. Respuesta observada HTTP 201; esperada HTTP 201. Evento enviado manualmente: no demuestra transporte automático desde Trip Execution.

[Captura completa](capturas/22-capturar-y-liquidar.png) · [Respuesta](capturas/22-capturar-y-liquidar-respuesta.png)

### 23. 23 liquidacion idempotente

Figura 23. Payments & Settlement: POST /api/v1/internal/events/trip-completed. Respuesta observada HTTP 200; esperada HTTP 200.

[Captura completa](capturas/23-liquidacion-idempotente.png) · [Respuesta](capturas/23-liquidacion-idempotente-respuesta.png)

### 24. 24 resumen ganancias

Figura 24. Payments & Settlement: GET /api/v1/settlements/me/summary. Respuesta observada HTTP 200; esperada HTTP 200.

[Captura completa](capturas/24-resumen-ganancias.png) · [Respuesta](capturas/24-resumen-ganancias-respuesta.png)

### 25. 25 marcar liquidacion pagada

Figura 25. Payments & Settlement: PATCH /api/v1/admin/settlements/{id}/mark-paid. Respuesta observada HTTP 200; esperada HTTP 200.

[Captura completa](capturas/25-marcar-liquidacion-pagada.png) · [Respuesta](capturas/25-marcar-liquidacion-pagada-respuesta.png)

### 26. 26 rechazar liquidacion ya pagada

Figura 26. Payments & Settlement: PATCH /api/v1/admin/settlements/{id}/mark-paid. Respuesta observada HTTP 409; esperada HTTP 409.

[Captura completa](capturas/26-rechazar-liquidacion-ya-pagada.png) · [Respuesta](capturas/26-rechazar-liquidacion-ya-pagada-respuesta.png)

### 27. 27 registro pasajero

Figura 27. Driver Management: POST /api/v1/auth/register. Respuesta observada HTTP 201; esperada HTTP 201.

[Captura completa](capturas/27-registro-pasajero.png) · [Respuesta](capturas/27-registro-pasajero-respuesta.png)

### 28. 28 revisar documento

Figura 28. Driver Management: PATCH /api/v1/driver-documents/{id}/review. Respuesta observada HTTP 200; esperada HTTP 200.

[Captura completa](capturas/28-revisar-documento.png) · [Respuesta](capturas/28-revisar-documento-respuesta.png)
