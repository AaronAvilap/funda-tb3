import json,uuid,hashlib,time,urllib.request,urllib.error
from pathlib import Path
from datetime import datetime,timezone
from playwright.sync_api import sync_playwright
ROOT=Path('/workspace/evidencia-shareway');(ROOT/'capturas').mkdir(exist_ok=True)
results=json.loads((ROOT/'resultados.json').read_text()) if (ROOT/'resultados.json').exists() else []
_uuid_counter=0
def stable_uuid():
 global _uuid_counter
 _uuid_counter+=1
 return uuid.uuid5(uuid.NAMESPACE_URL,'shareway-evidence-20261101-v2-'+str(_uuid_counter))
uuid.uuid4=stable_uuid
BASE={'planning':'http://localhost:8081','driver':'http://localhost:18082','payments':'http://localhost:18085','booking':'http://localhost:18080','execution':'http://localhost:18083'}
def api(s,m,path,body=None,token=None):
 h={'Content-Type':'application/json'}
 if token:h['Authorization']='Bearer '+token
 req=urllib.request.Request(BASE[s]+path,data=json.dumps(body).encode() if body is not None else None,headers=h,method=m)
 with urllib.request.urlopen(req) as r:return json.load(r)
def jwt(uid,role):
 import base64,hmac
 def enc(x):return base64.urlsafe_b64encode(json.dumps(x,separators=(',',':')).encode()).decode().rstrip('=')
 a=enc({'alg':'HS256','typ':'JWT'})+'.'+enc({'sub':'evidence@example.test','userId':uid,'role':role,'exp':int(time.time())+3600})
 return a+'.'+base64.urlsafe_b64encode(hmac.new(b'evidence-only-jwt-secret-minimum-thirty-two-characters',a.encode(),hashlib.sha256).digest()).decode().rstrip('=')
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1500,'height':1100},device_scale_factor=1);page.set_default_timeout(10000)
 service=None
 def run(s,method,path,label,body=None,params=None,auth=None,expected=200,desc=''):
  global service
  existing=next((r for r in results if r['capture']=='capturas/'+label+'.png'),None)
  if existing:
   return existing['response']
  if service!=s:
   page.goto(BASE[s]+('/swagger/index.html' if s=='execution' else '/swagger-ui/index.html'))
   page.wait_for_selector('.opblock',timeout=30000);service=s
  if auth:
   # Use Swagger UI's own supported authorization API; no response or contract substitution.
   scheme='internalApiKey' if auth=='internal' else 'bearerAuth'
   value='evidence-local-api-key' if auth=='internal' else auth
   page.evaluate('([name,value])=>window.ui.preauthorizeApiKey(name,value)',[scheme,value])
  op=page.locator('.opblock').filter(has=page.locator('.opblock-summary-path').filter(has_text=path))
  # exact method and path, because paths may contain each other
  op=page.locator('.opblock').filter(has=page.locator('.opblock-summary-path',has_text=path)).filter(has=page.locator('.opblock-summary-method',has_text=method.upper()))
  matches=[]
  for i in range(op.count()):
   x=op.nth(i)
   if x.locator('.opblock-summary-path').inner_text().strip()==path:matches.append(x)
  assert len(matches)==1,(s,method,path,len(matches))
  op=matches[0]
  if 'is-open' not in op.get_attribute('class'):op.locator('.opblock-summary').click()
  op.locator('.try-out__btn').first.wait_for()
  if op.locator('.try-out__btn').first.inner_text().strip()=='Try it out':op.locator('.try-out__btn').first.click()
  if body is not None:op.locator('textarea.body-param__text').fill(json.dumps(body,indent=2))
  for k,v in (params or {}).items():
   tr=op.locator('tr').filter(has=page.locator(f'[data-param-name="{k}"]'))
   tr=op.locator(f'tr[data-param-name="{k}"]')
   if not tr.count():tr=op.locator('tr').filter(has=page.locator('.parameter__name',has_text=k))
   tr.locator('input').first.fill(str(v))
  with page.expect_response(lambda r:r.request.method==method.upper() and r.url.startswith(BASE[s]) and '/swagger' not in r.url,timeout=30000) as resp:
   op.get_by_role('button',name='Execute',exact=True).click()
  response=resp.value
  try:data=response.json()
  except:data=response.text()
  op.locator('.live-responses-table').wait_for(timeout=15000)
  # Capture the operation through its live response, excluding static documented-response rows below.
  page.wait_for_timeout(150)
  box=op.bounding_box();live=op.locator('.live-responses-table').bounding_box()
  file='capturas/'+label+'.png'
  op.screenshot(path=str(ROOT/file),animations='disabled')
  op.locator('.live-responses-table').screenshot(path=str(ROOT/('capturas/'+label+'-respuesta.png')),animations='disabled')
  item={'service':s,'method':method,'path':path,'parameters':params,'request':body,'status':response.status,'expected':expected,'response':data,'capture':file,'description':desc,'timestamp_utc':datetime.now(timezone.utc).isoformat()}
  results.append(item);(ROOT/'resultados.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
  print(label,response.status,flush=True)
  # Keep failures visible and continue independent cases.
  item['passed']=response.status==expected
  (ROOT/'resultados.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
  op.locator('.opblock-summary').click()
  return data
 # Trip Planning: compatible data, generated UUID and replay
 run('planning','post','/api/v1/driver-availabilities','01-disponibilidad-operativa',{'driverId':10,'operationZone':'Chorrillos','availableDate':'2026-11-10','startTime':'07:00:00','endTime':'09:00:00','availableSeats':3},expected=201,desc='Registro de disponibilidad operativa por fecha.')
 req=run('planning','post','/api/v1/trip-requests','02-solicitud-viaje',{'passengerId':25,'originLabel':'UPC Monterrico','destinationLabel':'Chorrillos','operationZone':'Chorrillos','originLat':-12.1048,'originLng':-76.9632,'destinationLat':-12.1721,'destinationLng':-77.0164,'travelDate':'2026-11-10','earliestDeparture':'07:30:00','latestDeparture':'08:30:00','seatsRequested':1},expected=201,desc='Solicitud compatible con la disponibilidad creada.')
 pars={'tripRequestId':req['id']}
 first=run('planning','post','/api/v1/trip-requests/{tripRequestId}/match-proposals','03-generar-propuestas',params=pars,desc='Matching por zona, fecha, horario y cupos.');assert first
 replay=run('planning','post','/api/v1/trip-requests/{tripRequestId}/match-proposals','04-repeticion-idempotente',params=pars,desc='Repetición de la generación; se comprueba que devuelve los mismos IDs.');assert [p['id'] for p in first]==[p['id'] for p in replay]
 run('planning','get','/api/v1/trip-requests/{tripRequestId}/match-proposals','05-consultar-propuestas',params=pars)
 run('planning','post','/api/v1/trip-requests','06-validacion-solicitud-invalida',{},expected=400,desc='Validación de campos obligatorios.')
 # Driver Management: real registration/login, driver role from supported profile operation
 user=api('driver','POST','/api/v1/auth/register',{'email':'driver.evidence2@example.test','password':'Evidence123','fullName':'Conductor de Prueba','phone':'999111222'})
 token=api('driver','POST','/api/v1/auth/login',{'email':'driver.evidence2@example.test','password':'Evidence123'})['accessToken']
 api('driver','POST','/api/v1/users/me/driver-profile',{'licenseNumber':'EVID123457','emergencyContact':{'name':'Contacto Prueba','phone':'999333444','relationship':'Familiar'}},token)
 token=api('driver','POST','/api/v1/auth/login',{'email':'driver.evidence2@example.test','password':'Evidence123'})['accessToken']
 sched={'slots':[{'dayOfWeek':'MONDAY','startTime':'07:00','endTime':'09:00'}]}
 run('driver','put','/api/v1/drivers/me/availability','07-guardar-agenda-semanal',sched,auth=token)
 run('driver','get','/api/v1/drivers/me/availability','08-consultar-agenda-semanal',auth=token)
 run('driver','put','/api/v1/drivers/me/availability','09-rechazar-solapamiento',{'slots':sched['slots']+[{'dayOfWeek':'MONDAY','startTime':'08:00','endTime':'10:00'}]},auth=token,expected=400)
 # Booking: seeded local group and synthetic passenger
 passenger=str(uuid.uuid4());booking_body={'requestId':str(uuid.uuid4()),'groupId':'11111111-1111-1111-1111-111111111111'}
 bp={'X-User-Id':passenger,'Idempotency-Key':str(uuid.uuid4())}
 run('booking','get','/fares/estimate','10-estimar-tarifa',params={'groupId':booking_body['groupId']})
 bk=run('booking','post','/bookings','11-crear-reserva',booking_body,params=bp,expected=202)
 replay=run('booking','post','/bookings','12-reserva-idempotente',booking_body,params=bp,expected=202);assert bk['bookingId']==replay['bookingId']
 run('booking','post','/bookings/{bookingId}/cancel','13-cancelar-reserva',params={'bookingId':bk['bookingId'],'X-User-Id':passenger})
 # Trip Execution: independent service fixture, not an end-to-end integration
 driver=str(uuid.uuid4());reservation=str(uuid.uuid4());passenger2=str(uuid.uuid4())
 trip=run('execution','post','/api/viajes','14-crear-viaje',{'grupoId':str(uuid.uuid4()),'conductorId':driver,'pasajeros':[{'reservaId':reservation,'pasajeroId':passenger2,'codigoHash':hashlib.sha256(b'123456').hexdigest()}]},expected=201)
 tp={'id':trip['id']}
 run('execution','post','/api/viajes/{id}/iniciar','15-rechazar-inicio-sin-abordaje',{'conductorId':driver},params=tp,expected=409)
 run('execution','post','/api/viajes/{id}/abordajes','16-validar-abordaje',{'conductorId':driver,'reservaId':reservation,'codigo':'123456','metodo':'Pin'},params=tp)
 run('execution','post','/api/viajes/{id}/iniciar','17-iniciar-viaje',{'conductorId':driver},params=tp,desc='Respuesta observada 200; las anotaciones también anuncian 204.')
 run('execution','post','/api/viajes/{id}/finalizar','18-finalizar-viaje',{'conductorId':driver},params=tp)
 run('execution','get','/api/viajes/{id}','19-consultar-viaje-finalizado',params=tp)
 # Payments: locally signed synthetic test JWTs; no claim of real identity integration
 ptoken=jwt(passenger2,'PASSENGER');dtoken=jwt(driver,'DRIVER');atoken=jwt(str(uuid.uuid4()),'ADMIN')
 card=run('payments','post','/api/v1/payment-methods','20-registrar-metodo-pago',{'cardToken':'tok_approved','brand':'VISA','last4':'4242','expMonth':12,'expYear':2030},auth=ptoken,expected=201)
 run('payments','post','/api/v1/internal/payments/authorizations','21-autorizar-pago',{'bookingId':reservation,'passengerId':passenger2,'paymentMethodId':card['id'],'amount':40,'currency':'PEN'},auth='internal',expected=201)
 event={'tripId':trip['id'],'driverId':driver,'completedAt':datetime.now(timezone.utc).isoformat(),'bookings':[{'bookingId':reservation,'finalAmount':40}]}
 settlement=run('payments','post','/api/v1/internal/events/trip-completed','22-capturar-y-liquidar',event,auth='internal',expected=201,desc='Evento enviado manualmente: no demuestra transporte automático desde Trip Execution.')
 again=run('payments','post','/api/v1/internal/events/trip-completed','23-liquidacion-idempotente',event,auth='internal');assert settlement['id']==again['id']
 run('payments','get','/api/v1/settlements/me/summary','24-resumen-ganancias',auth=dtoken)
 run('payments','patch','/api/v1/admin/settlements/{id}/mark-paid','25-marcar-liquidacion-pagada',params={'id':settlement['id']},auth=atoken)
 run('payments','patch','/api/v1/admin/settlements/{id}/mark-paid','26-rechazar-liquidacion-ya-pagada',params={'id':settlement['id']},auth=atoken,expected=409)
 browser.close()
